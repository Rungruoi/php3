<!DOCTYPE html>
<html>

<!-- Mirrored from mobirise.com/bootstrap-4-theme/real-estate-template/rental.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Aug 2019 06:37:37 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <!-- Site made with Mobirise Website Builder v4.4.1, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.4.1, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="assets/images/logo2-1.png" type="image/x-icon">
  <meta name="description" content="New Bootstrap 4 HTML Real Estate Template - Rental Item - Free Download">
  <title>Free HTML Bootstrap 4 Real Estate Template - Rental</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/soundcloud-plugin/style.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>

<!-- Google Analytics -->
<noscript><iframe src="http://www.googletagmanager.com/ns.html?id=GTM-PFK425"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PFK425');</script>

<!-- /Google Analytics -->


<section class="menu cid-qxQrbs9zxD" once="menu" id="menu1-r" data-rv-view="6716">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color transparent">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                
                <span class="navbar-caption-wrap"><a class="navbar-caption text-white display-4" href="https://mobirise.com/bootstrap-template/">
                        REAL ESTATE TEMPLATE</a></span>
            </div>
        </div>
         <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown"><a class="nav-link link dropdown-toggle text-white display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        
                        BLOCK DEMOS 1</a><div class="dropdown-menu"><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/slider.html">Slider Header Demo</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/video-background.html">Video Background Demo</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/footer-template.html">Footer Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/table-template.html">Table Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/carousel-template.html">Carousel Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/blog.html">Gallery Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/menu-template.html">Menu Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/navigation-menu-template.html">Navigation Menu Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/navbar-template.html">Navbar Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/header-template.html">Header Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/registration-form-template.html">Registration Form Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/grid-template.html">Grid Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/social-network-template.html">Social Network Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/parallax-template.html">Parallax Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/parallax-scrolling-template.html">Parallax Scrolling Template</a></div></li>
                <li class="nav-item dropdown"><a class="nav-link link dropdown-toggle text-white display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        
                        BLOCK DEMOS 2</a><div class="dropdown-menu"><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/shopping-cart-template.html">Shopping Cart Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/contact-form-template.html">Contact Form Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/list-template.html">List Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/video-template.html">Video Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/photo-gallery-template.html">Photo Gallery Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/map-template.html">Map Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/faq-template.html">FAQ Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/slider-template.html">Slider Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/background-template.html">Video Background Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/documentation-template.html">Documentation Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/article-template.html">Article Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/google-maps-template.html">Google Maps Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/form-templates.html">Form Templates </a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/tab-template.html">Tab Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/video-gallery-template.html">Video Gallery Template</a></div></li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link link dropdown-toggle text-white display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">SITE TEMPLATES 1</a><div class="dropdown-menu"><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/one-page.html">One Page Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/blog.html">Blog Template Demo<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/real-estate-template/">Real Estate Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/restaurant-template/">Restaurant Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/travel-template/">Travel Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/wedding-template/">Wedding Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/hotel-template/">Hotel Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/landing-page-template/">Landing Page Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/news-template/">News Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/profile-template/">Profile Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/education-template/">Education Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/coming-soon-template/">Coming Soon Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/error-page-template/">Error Page Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/event-template/">Event Template<br></a></div>
                </li><li class="nav-item dropdown open"><a class="nav-link link dropdown-toggle text-white display-4" href="#" aria-expanded="true" data-toggle="dropdown-submenu">SITE TEMPLATES 2</a><div class="dropdown-menu"><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/about-us-page-template/" aria-expanded="false">About Us Page Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/agency-template/" aria-expanded="false">Agency Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/application-template/" aria-expanded="false">Application Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/business-template/" aria-expanded="false">Business Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/corporate-template/" aria-expanded="false">Corporate Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/homepage-template/" aria-expanded="false">Homepage Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/magazine-template/" aria-expanded="false">Magazine Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/agency-template/multi-page-template.html" aria-expanded="false">Multi Page Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/personal-website-template/" aria-expanded="false">Personal Website Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/photography-template/" aria-expanded="false">Photography Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/store-template/" aria-expanded="false">Store Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-template/web-application-template/" aria-expanded="false">Web Application Template</a></div></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-primary display-4" href="https://mobirise.com/bootstrap-template/mobirise-free-template.zip">
                    
                    FREE DOWNLOAD</a></div>
        </div>
    </nav>
</section>

<section class="engine"><a href="https://mobirise.co/o">bootstrap buttons</a></section><section class="mbr-section info2 cid-qwwWOR8vxM" id="info2-k" data-rv-view="6718">

    

    

    <div class="container">
        <div class="row justify-content-center">
            <div class="media-container-column col-12 col-lg-3 col-md-4">
                <div class="mbr-section-btn align-left py-4"><a class="btn btn-black display-4" href="index.html"><span class="mbri-left mbr-iconfont mbr-iconfont-btn"></span>
                    
                    BACK TO HOME</a></div>
            </div>
            <div class="media-container-column title col-12 col-lg-7 col-md-6">
                <h1 class="align-right mbr-bold mbr-white pb-3 mbr-fonts-style display-2">REAL ESTATE TEMPLATE. RENTAL ITEM</h1>
                
            </div>
        </div>
    </div>
</section>

<section class="mbr-section content4 cid-qwwSqvnWgv" id="content4-j" data-rv-view="6721">

    

    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center pb-3 mbr-fonts-style display-5">4494 Pinchelone Street, Norfolk</h2>
                <h3 class="mbr-section-subtitle align-center mbr-light mbr-fonts-style display-7">
                    2Bedroom, pet-friendly, 6 floor</h3>
                
            </div>
        </div>
    </div>
</section>

<section class="cid-qwwSpEZubr" id="image1-i" data-rv-view="6723">

    

    <figure class="mbr-figure container">
            <div class="image-block" style="width: 64%;">
                <img src="assets/images/breather-196135-2800x1863.jpg" width="1400" alt="Mobirise" title="" media-simple="true">
                
            </div>
    </figure>
</section>

<section class="map2 cid-qwwSkh27AD" id="map2-e" data-rv-view="6725">

    

    <div class="container">
        <div class="media-container-row">
            <div class="col-md-8">
                <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0Dx_boXQiwvdz8sJHoYeZNVTdoWONYkU&amp;q=place_id:ChIJn6wOs6lZwokRLKy1iqRcoKw" allowfullscreen=""></iframe></div>
        </div>
    </div>
</div></section>

<section class="features11 cid-qwwSnDZIoo" id="features11-g" data-rv-view="6727">

    

    

    <div class="container">   
        <div class="col-md-12">
            <div class="media-container-row">
                <div class="mbr-figure" style="width: 50%;">
                    <img src="assets/images/breather-7169-2000x1335.jpg" alt="Mobirise" title="" media-simple="true">
                </div>
                <div class=" align-left">
                    <h2 class="mbr-title pt-2 mbr-fonts-style display-2">
                        2 Bedroom</h2>
                    <div class="mbr-section-text">
                        <p class="mbr-text mb-5 pt-3 mbr-light mbr-fonts-style display-7">
                        Donec laoreet massa quis metus finibus, sed rhoncus leo mattis. Vivamus tincidunt interdum nunc id accumsan.
                        </p>
                    </div>

                    <div class="block-content">
                        <div class="card p-3 pr-3">
                            <div class="media">
                                     
                                <div class="media-body">
                                    <h4 class="card-title mbr-fonts-style display-7">
                                        Pet-friendly</h4>
                                </div>
                            </div>                

                            <div class="card-box">
                                <p class="block-text mbr-fonts-style display-7">
                                   Suspendisse convallis ex dui, a efficitur magna maximus non. Aenean eget quam velit. Donec porttitor ligula eu lacus bibendum, sit amet vehicula ex tincidunt. 
                                </p>
                            </div>
                        </div>

                        <div class="card p-3 pr-3">
                            <div class="media">
                                     
                                <div class="media-body">
                                    <h4 class="card-title mbr-fonts-style display-7">
                                        Laundry</h4>
                                </div>
                            </div>                

                            <div class="card-box">
                                <p class="block-text mbr-fonts-style display-7">
                                    Sed dictum, enim et consectetur vulputate, ipsum turpis porttitor libero, vel ultrices dolor nisi vitae nulla.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div>          
</section>

<section class="features12 cid-qwwSo2FWgA" id="features12-h" data-rv-view="6730">
    
    

    

    <div class="container">
        <h2 class="mbr-section-title pb-2 mbr-fonts-style display-2">Maecenas accumsan non diam</h2>
        <h3 class="mbr-section-subtitle pb-3 mbr-fonts-style display-5">
            Click any text or icon to edit or style it. Use the block parameters to hide/show text or icons and change media size.
        </h3>

        <div class="media-container-row pt-5">
            <div class="block-content align-right">
                <div class="card pl-3 pr-3 pb-5">
                    <div class="mbr-card-img-title">
                        
                        <div class="mbr-crt-title">
                            <h4 class="card-title py-2 mbr-crt-title mbr-fonts-style display-7">
                                Parks</h4>
                        </div>
                    </div>                

                    <div class="card-box">
                        <p class="mbr-text mbr-section-text mbr-fonts-style display-7">
                            Vivamus eget lorem egestas, placerat dui vitae, accumsan velit. Suspendisse sodales ante cursus velit pulvinar luctus.
                        </p>
                    </div>
                </div>

                <div class="card pl-3 pr-3 pb-5">
                    <div class="mbr-card-img-title">
                        
                        <div class="mbr-crt-title">
                            <h4 class="card-title py-2 mbr-crt-title mbr-fonts-style display-7">
                                Parking</h4>
                        </div>
                    </div>
                    <div class="card-box">
                        <p class="mbr-text mbr-section-text mbr-fonts-style display-7">
                            Etiam sodales pulvinar sem, quis auctor est laoreet vel. Nunc est neque, sagittis sit amet sapien et, ullamcorper vehicula mi.
                        </p>
                    </div>
                </div>
            </div>

            <div class="mbr-figure" style="width: 50%;">
                <img src="assets/images/joel-filipe-166058-2000x2831.jpg" alt="Mobirise" title="" media-simple="true">
            </div>

            <div class="block-content align-left  ">
                <div class="card pl-3 pr-3 pb-5">
                    <div class="mbr-card-img-title">
                        
                        <div class="mbr-crt-title">
                            <h4 class="card-title py-2 mbr-crt-title mbr-fonts-style display-7">
                                Schools</h4>
                        </div>
                    </div>                

                    <div class="card-box">
                        <p class="mbr-text mbr-section-text mbr-fonts-style display-7">
                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. 
                        </p>
                    </div>
                </div>

                <div class="card pl-3 pr-3 pb-5">
                    <div class="mbr-card-img-title">
                        
                        <div class="mbr-crt-title">
                            <h4 class="card-title py-2 mbr-crt-title mbr-fonts-style display-7">Community Features</h4>
                        </div>
                    </div>
                    <div class="card-box">
                        <p class="mbr-text mbr-section-text mbr-fonts-style display-7">
                            Mauris at est libero. Cras feugiat quis elit a faucibus. Cras eget consectetur leo, vitae accumsan metus. 
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="mbr-section info2 cid-qwwSlIUiIP" id="info2-f" data-rv-view="6733">

    

    

    <div class="container">
        <div class="row justify-content-center">
            <div class="media-container-column col-12 col-lg-3 col-md-4">
                <div class="mbr-section-btn align-left py-4"><a class="btn btn-black display-4" href="https://mobirise.com/">
                    
                    +1-757-284-7453</a></div>
            </div>
            <div class="media-container-column title col-12 col-lg-7 col-md-6">
                <h2 class="align-right mbr-bold mbr-white pb-3 mbr-fonts-style display-2">CALL OUR AGENT NOW</h2>
                <h3 class="mbr-section-subtitle align-right mbr-light mbr-white mbr-fonts-style display-7">Nunc eu vestibulum nisi, in fermentum augue.</h3>
            </div>
        </div>
    </div>
</section>

<section once="" class="cid-qwx6e5j1Bl" id="footer6-l" data-rv-view="6736">

    

    

    <div class="container">
        <div class="media-container-row align-center mbr-white">
            <div class="col-12">
                <p class="mbr-text mb-0 mbr-fonts-style display-7">
                    © Copyright 2019<a href="https://mobirise.com/bootstrap-template/" class="text-white"> Free Bootstrap Templates </a>- All Rights Reserved
                </p>
            </div>
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  
  
</body>

<!-- Mirrored from mobirise.com/bootstrap-4-theme/real-estate-template/rental.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Aug 2019 06:37:40 GMT -->
</html><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/client/rental.blade.php ENDPATH**/ ?>