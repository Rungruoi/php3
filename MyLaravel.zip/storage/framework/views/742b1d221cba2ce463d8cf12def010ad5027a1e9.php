<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Posts</h3>

          <div class="box-tools">
            <form action="" method="get">
                <div class="input-group input-group-sm hidden-xs" style="width: 150px;">
                  <input type="text" name="keyword" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
            </form>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body table-responsive no-padding">
          <table class="table table-hover">
            <tbody>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>slug</th>
              <th>Description</th>
              <th>Image</th>
              <th>Status</th>
              <th>
                  <a href="<?php echo e(route('product.add')); ?>" class="btn btn-sm btn-success">Add</a>
              </th>
            </tr>
            <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>$key</td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->slug); ?></td>
                    <td><?php echo e($item->description); ?></td>
                    <td>
                        <img src="<?php echo e($item->feature_image); ?>" width="100" >
                    </td>
                    <td><?php echo e($item->status); ?></td>
                     <td>
                        <a href="<?php echo e(route('product.remove', 
                        ['id' => $item->id])); ?>" class="btn btn-sm btn-success" title="">Eidt</a>
                        <a href="<?php echo e(route('product.remove', 
                        ['id' => $item->id])); ?>" class="btn btn-sm btn-danger" title="" >Remove</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/admin/products/product.blade.php ENDPATH**/ ?>