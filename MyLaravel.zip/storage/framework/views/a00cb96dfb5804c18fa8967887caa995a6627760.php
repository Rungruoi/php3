<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('category.add')); ?>" method="post" enctype="multipart/form-data" novalidate>
	<?php echo csrf_field(); ?>
	<div class="form-group">
		<label for="">Tên danh mục-(Name Cate)</label>
		<input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="">
		<?php if( $errors->first('name')): ?>
		<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		<?php endif; ?>
	</div>	
	
	<div class="form-group">
		<label for="">Mô tả-(Description)</label>
		<textarea name="description" rows="10" class="form-control"><?php echo e(old('description')); ?></textarea>
		<?php if( $errors->first('description')): ?>
		<span class="text-danger"><?php echo e($errors->first('description')); ?></span>
		<?php endif; ?>
	</div>		
	
	
<div>		<div>
	<button type="submit" class="btn btn-sm btn-success">Lưu</button>
	<a href="<?php echo e(route('categories')); ?>" class="btn btn-sm btn-danger">Hủy</a>
</div>		</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/cate/add-category.blade.php ENDPATH**/ ?>