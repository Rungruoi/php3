<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	Bạn không có quyền truy cập vào chức năng này!
</body>
</html><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/auth/403.blade.php ENDPATH**/ ?>