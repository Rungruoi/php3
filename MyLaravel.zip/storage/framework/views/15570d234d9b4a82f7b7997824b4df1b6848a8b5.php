
	<form action="<?php echo e(route('postForm')); ?>" method="POST" accept-charset="utf-8">
	<?php echo csrf_field(); ?>		
		<input type="text" name="Hoten">
		<input type="submit" value="Submit">
	</form>
<?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/postForm.blade.php ENDPATH**/ ?>