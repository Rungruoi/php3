<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('post.add')); ?>" method="post" enctype="multipart/form-data" novalidate>
	<?php echo csrf_field(); ?>
	<div class="col-md-6">
	<div class="form-group">
		<label for="">Tiêu đề*</label>
		<input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder="">
		<?php if( $errors->first('title')): ?>
		<span class="text-danger"><?php echo e($errors->first('title')); ?></span>
		<?php endif; ?>
	</div>	
<div class="form-group">
		<label for="">Tác giả*</label>
				<input type="text" name="auther" class="form-control" value="<?php echo e(old('auther')); ?>">
				<?php if( $errors->first('auther')): ?>
		<span class="text-danger"><?php echo e($errors->first('auther')); ?></span>
		<?php endif; ?>
		
</div>		
<div class="form-group">
	<label for="">Ngày đăng</label>
	<input type="date" name="publish_date" class="form-control" placeholder="" value="<?php echo e(old('publish_data')); ?>">
	<?php if( $errors->first('publish_date')): ?>
		<span class="text-danger"><?php echo e($errors->first('publish_date')); ?></span>
		<?php endif; ?>
</div>
<div class="form-group">
	<label for="">Danh mục</label>
	<select name="cate_id" class="form-control">
		<?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</select>

	
</div>	
<?php if( $errors->first('cate_id')): ?>
		<span class="text-danger"><?php echo e($errors->first('cate_id')); ?></span>
		<?php endif; ?>	

</div>

<div>		<div>
	<div class="col-md-6">	
	<div class="form-group">
		<label>Ảnh</label>
		<input type="file" name="image" class="form-control" value="<?php echo e(old('image')); ?>" placeholder="">
		<?php if( $errors->first('image')): ?>
		<span class="text-danger"><?php echo e($errors->first('image')); ?></span>
		<?php endif; ?>
	</div>	
	<div class="checkbox">
	<label>
		<input type="checkbox" value="1" name="status"> Active
	</label>
</div>
	</div>	
	<div class="col-md-12">	
		<div class="form-group">
		<label for="">Nội dung*</label>
		<textarea name="content" rows="10" class="form-control" id="editor1"><?php echo e(old('content')); ?></textarea>
		<?php if( $errors->first('content')): ?>
		<span class="text-danger"><?php echo e($errors->first('content')); ?></span>
		<?php endif; ?>
	</div>		
	</div>
	
			
	<button type="submit" class="btn btn-sm btn-success"><i class="fa fa-floppy-o" aria-hidden="true"></i>Lưu</button>
	<a href="<?php echo e(route('homepage')); ?>" class="btn btn-sm btn-danger">Hủy</a>
</div>		</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/post/add-form.blade.php ENDPATH**/ ?>