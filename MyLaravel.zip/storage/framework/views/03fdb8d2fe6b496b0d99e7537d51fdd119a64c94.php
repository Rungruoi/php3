<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('user.edit', ['id' => $users->id])); ?>" method="post" enctype="multipart/form-data" novalidate>
	<?php echo csrf_field(); ?>
	<div class="col-md-6">
	<div class="form-group">
		<input type="hidden" name="id" value="<?php echo e($users->id); ?>">
		<label for="">Tên - (Name users)</label>
		<input type="text" name="name" class="form-control" value="<?php echo e($users->name); ?>" placeholder="">
		<?php if( $errors->first('name')): ?>
		<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		<?php endif; ?>
	</div>	
	<div class="form-group">
		<label for="">Email</label>

		<input type="email" name="email" class="form-control" value="<?php echo e($users->email); ?>">
		<?php if( $errors->first('email')): ?>
		<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
		<?php endif; ?>
	</div>
	<div class="form-group">
		<label for="">Quyền truy cập-(Role)</label>
		<select name="role" id="" class="form-control" <?php if($users->role==900): ?> readonly <?php endif; ?>>

		<option value="1" <?php if($users->role==1): ?> selected <?php endif; ?> >User</option>
		<option value="300" <?php if($users->role==300): ?> selected <?php endif; ?>>Member</option>
		<option value="500" <?php if($users->role==500): ?> selected <?php endif; ?>>Admin</option>
		</select>
	</div>	
	<div class="form-group">
		<label for="">Số điện thoại -(Number-phone)</label>
		<input type="number" name="numberphone" class="form-control" value="<?php echo e("0".$users->numberphone); ?>">
		<?php if( $errors->first('numberphone')): ?>
		<span class="text-danger"><?php echo e($errors->first('numberphone')); ?></span>
		<?php endif; ?>
	</div>
	
	</div>
	<div class="col-md-6">
	<div class="form-group">
		<label for="">Địa chỉ-(Address)</label>
		<textarea name="address"  rows="10" class="form-control"><?php echo e($users->address); ?></textarea>
		<?php if( $errors->first('address')): ?>
		<span class="text-danger"><?php echo e($errors->first('address')); ?></span>
		<?php endif; ?>
	</div>	
</div>
	
	<button type="submit" class="btn btn-sm btn-success">Lưu</button>
	<a href="<?php echo e(route('user')); ?>" class="btn btn-sm btn-danger">Hủy</a>
</div>		</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/user/edit-user.blade.php ENDPATH**/ ?>