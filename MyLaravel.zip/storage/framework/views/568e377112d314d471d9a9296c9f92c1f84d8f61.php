<!-- sidebar menu: : style can be found in sidebar.less -->
<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
   <li>
    <a href="<?php echo e(route('categories')); ?>">
      <i class="fa fa-gift"></i> <span>Categores</span>
      <span class="pull-right-container">
        <small class="label pull-right bg-green"></small>
      </span>
    </a>
  </li>
  <li>
  <li>
    <a href="<?php echo e(url('admin')); ?>">
      <i class="fa fa-clipboard"></i> <span>Post</span>
      <span class="pull-right-container">
        
      </span>
    </a>
  </li>

  <li>
    <a href="<?php echo e(route('products')); ?>">
      <i class="fa fa-gift"></i> <span>Product</span>
      <span class="pull-right-container">
        <small class="label pull-right bg-green">new</small>
      </span>
    </a>
  </li>
   <li>
    <a href="<?php echo e(route('user')); ?>">
      <i class="fa fa-gift"></i> <span>Users</span>
      <span class="pull-right-container">
        <small class="label pull-right bg-green">new</small>
      </span>
    </a>
  </li>
  <li>
     
  
</ul><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>