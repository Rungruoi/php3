<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xs-12">
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">Products</h3>

        <div class="box-tools">
          <form action="" method="get">
            <div class="input-group input-group-sm hidden-xs" style="width: 150px;">
              <input type="text" name="keyword" class="form-control pull-right" placeholder="Search">

              <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tbody>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Price</th>
              <th>cate</th>
              <th>slug</th>
              <th>Description</th>
              <th>Image</th>
              <th>Status</th>
              <th >
                <a href="<?php echo e(route('product.add')); ?>" class="btn btn-sm btn-success">Add</a>
              </th>
            </tr>
            <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($item->id); ?></td>
              <td><?php echo e($item->name); ?></td>
              <td><?php echo e($item->price); ?></td>
              <td><?php echo e($item->categorysp->name); ?></td>
              <td><?php echo e(substr($item->slug,-100)); ?></td>
              <td><?php echo substr($item->description,-150); ?></td>
              <td>
                <img src="<?php echo e($item->feature_image); ?>" width="100" >
              </td>
              <td><?php if($item->status==1): ?>
                <a class="btn btn-xs btn-info">
                        Hiện
                      </a>
                <?php else: ?>
                <a class="btn btn-xs btn-warning">
                Ẩn</a>
              <?php endif; ?></td>
              <td>
                <a href="<?php echo e(route('product.edit', 
                ['id' => $item->id])); ?>" class="btn btn-sm btn-success" title="">Eidt</a>
                
                
            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#<?php echo e($item->id); ?>">
  Remove
</button>
                  <!-- Modal -->
                <div class="modal fade" id="<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog " role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h3 class="modal-title text-success" id="exampleModalLabel">Modal</h3>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body text-danger">
            
          <h4>Bạn có muốn xóa bài viết này không!</h4>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            
            <a href="<?php echo e(route('product.remove', 
            ['id' => $item->id])); ?>"  title="" >
            <button type="button" class="btn btn-primary">Đồng ý</button></a>
          </div>
        </div>
      </div>
    </div>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>

              <td colspan="4" class="text-center">
               <?php echo e($pro->links()); ?>

             </td>

           </tr>
         </tbody>
       </table>
     </div>
     <!-- /.box-body -->



  </div>
  <!-- /.box -->
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/product/products.blade.php ENDPATH**/ ?>