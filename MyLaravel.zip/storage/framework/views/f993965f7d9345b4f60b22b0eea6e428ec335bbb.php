<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xs-6">
    <form action="<?php echo e(route('category.add')); ?>" method="post" enctype="multipart/form-data" novalidate>
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="">Tên danh mục-(Name Cate*)</label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="">
        <?php if( $errors->first('name')): ?>
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
      </div>  
      
      <div class="form-group">
        <label for="">Mô tả-(Description*)</label>
        <textarea name="description" rows="10" class="form-control" id="editor1"><?php echo e(old('description')); ?></textarea>
        <?php if( $errors->first('description')): ?>
        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
        <?php endif; ?>
      </div>    
      
      
      <div>   <div>
        <button type="submit" class="btn btn-sm btn-success">Lưu</button>
        
        <a href="<?php echo e(route('categories')); ?>" class="btn btn-sm btn-danger">Hủy</a>
        
        <!-- Modal -->

        
        

      </div>    </div>

    </form>
  </div>
  <div class="col-xs-6">
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">Category</h3>

        <div class="box-tools">
          <form action="" method="get">
            <div class="input-group input-group-sm hidden-xs" style="width: 150px;">
              <input type="text" name="keyword" class="form-control pull-right" placeholder="Search">

              <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tbody>
            <tr>
              
              <th>Name</th>
              
              <th>Description</th>
              
              <th >
               
              </th>
            </tr>
            <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
              <td><?php echo e($item->name); ?></td>
              
              <td><?php echo $item->description; ?></td>
              <td>
                <a href="<?php echo e(route('category.edit', 
                ['id' => $item->id])); ?>" class="btn btn-sm btn-success" title=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Eidt</a>
                
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#<?php echo e($item->id); ?>"><i class="fa fa-trash" aria-hidden="true"></i>
                  Remove
                </button>
                <!-- Modal -->
     <div class="modal fade" id="<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <h4>Bạn có muốn xóa danh mục này!</h4>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
            <a href="<?php echo e(route('category.remove', 
            ['id' => $item->id])); ?>"  title="" >
            <button type="button" class="btn btn-primary">Đồng ý</button></a>
          </div>
        </div>
      </div>
    </div>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
             
              <td colspan="4" class="text-center">
               <?php echo e($cate->links()); ?>

             </td>
             
           </tr>
         </tbody>
       </table>
     </div>
     
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/cate/category.blade.php ENDPATH**/ ?>