<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('product.edit',['id' => $pro->id])); ?>" method="post" enctype="multipart/form-data" novalidate>
	<?php echo csrf_field(); ?>
	<div class="col-md-6">
	<div class="form-group">
		<label for="">Tên sản phẩm-(Name Product)*</label>
		<input type="text" name="name" class="form-control" value="<?php echo e($pro->name); ?>" placeholder="">
		<?php if( $errors->first('name')): ?>
		<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		<?php endif; ?>
	</div>	
	<div class="form-group">
		<label for="">Slug*</label>
		<input type="text" name="slug" class="form-control" value="<?php echo e($pro->slug); ?>" placeholder="">
		<?php if( $errors->first('slug')): ?>
		<span class="text-danger"><?php echo e($errors->first('slug')); ?></span>
		<?php endif; ?>
	</div>	
	<div class="form-group">
		<label for="">Danh mục</label>
		<select name="pro_id" class="form-control">
			<option value="<?php echo e($pro->pro_id); ?>"><?php echo e($pro->categorysp['name']); ?></option>
			<?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($item->id); ?>" ><?php echo e($item->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</select>

	</div>	
	<?php if( $errors->first('pro_id')): ?>
	<span class="text-danger"><?php echo e($errors->first('pro_id')); ?></span>
	<?php endif; ?>	
	<div class="form-group">
		<lable>Giá Sản Phẩm</lable>
		<input type="number" name="price" class="form-control" value="<?php echo e($pro->price); ?>">
	</div>
	<?php if( $errors->first('price')): ?>
		<span class="text-danger"><?php echo e($errors->first('price')); ?></span>
		<?php endif; ?>	
</div>
<div class="col-md-6">
	<div class="form-group">
        <img id="showImage" src="<?php echo e($pro->feature_image); ?>" width="200" class="img-responsive" name="img"> 

     	</div>
	<div class="form-group">
		<label>Ảnh-(feature_image)</label>
		<input type="file" name="feature_image" class="form-control" value="<?php echo e($pro->feature_image); ?>" placeholder="">
		<?php if( $errors->first('feature_image')): ?>
		<span class="text-danger"><?php echo e($errors->first('feature_image')); ?></span>
		<?php endif; ?>
	</div>

</div>	
<div class="col-md-12">	
	<div class="form-group">
		<label for="">Mô tả-(Description)</label>
		<textarea name="description" rows="10" id="editor1" class="form-control"><?php echo e($pro->description); ?></textarea>
		<?php if( $errors->first('description')): ?>
		<span class="text-danger"><?php echo e($errors->first('description')); ?></span>
		<?php endif; ?>
	</div>		
	</div>
	
<div class="form-group">
	<label>
		<input type="checkbox" value="1" name="status" <?php if($pro->status==1): ?> checked <?php endif; ?>> Active
	</label>
	
</div>
<div>		<div>
	<button type="submit" class="btn btn-sm btn-success">Lưu</button>
	<a href="<?php echo e(route('homepage')); ?>" class="btn btn-sm btn-danger">Hủy</a>
</div>		</div>

</form>
<script>

    var img = document.querySelector('[name="feature_image"]');
    img.onchange = function(){
      var anh = this.files[0];
      if(anh == undefined){
        document.querySelector('#showImage').src = "";
      }else{
        getBase64(anh, '#showImage');
      }
      getBase64(anh, '#showImage');
    }
    function getBase64(file, selector) {
       var reader = new FileReader();
       reader.readAsDataURL(file);
       reader.onload = function () {
         document.querySelector(selector).src = reader.result;
       };
       reader.onerror = function (error) {
         console.log('Error: ', error);
       };
    }
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/product/edit-product.blade.php ENDPATH**/ ?>