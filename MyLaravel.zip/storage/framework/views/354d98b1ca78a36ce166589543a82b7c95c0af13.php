<!DOCTYPE html>
<html>

<!-- Mirrored from mobirise.com/bootstrap-4-theme/real-estate-template/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Aug 2019 06:37:14 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<base href="/" />
<head>
  <!-- Site made with Mobirise Website Builder v4.4.1, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.4.1, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="assets/images/logo2-1.png" type="image/x-icon">
  <meta name="description" content="Latest Bootstrap 4 HTML5 Real Estate Template - Free Download">
  <title>Laravel PHP3</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/soundcloud-plugin/style.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>

<!-- Google Analytics -->
<noscript><iframe src="http://www.googletagmanager.com/ns.html?id=GTM-PFK425"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PFK425');</script>

<!-- /Google Analytics -->


<section class="menu cid-qB8Q1MCP76" once="menu" id="menu2-s" data-rv-view="6714">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color transparent">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                
                <span class="navbar-caption-wrap"><a class="navbar-caption text-white display-4" href="<?php echo e(url('/')); ?>">
                        <h2>Real Estate</h2></a></span>
            </div>
        </div>
         <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown"><a class="nav-link link dropdown-toggle text-white display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        
                        BLOCK DEMOS</a></li>
                <li class="nav-item dropdown open"><a class="nav-link link dropdown-toggle text-white display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="true">
                        
                        BLOCK DEMOS 2</a><div class="dropdown-menu"><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/shopping-cart-template.html">Shopping Cart Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/contact-form-template.html">Contact Form Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/list-template.html">List Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/video-template.html">Video Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/photo-gallery-template.html">Photo Gallery Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/map-template.html">Map Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/faq-template.html">FAQ Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/slider-template.html">Slider Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/background-template.html">Video Background Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/documentation-template.html">Documentation Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/article-template.html">Article Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/google-maps-template.html">Google Maps Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/form-templates.html">Form Templates </a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/tab-template.html">Tab Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/video-gallery-template.html">Video Gallery Template</a></div></li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link link dropdown-toggle text-white display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">SITE TEMPLATES</a><div class="dropdown-menu"><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/one-page.html">One Page Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/blog.html">Blog Template Demo<br></a><a class="dropdown-item text-white display-4" href="index.html">Real Estate Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/restaurant-template/">Restaurant Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/travel-template/">Travel Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/wedding-template/">Wedding Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/hotel-template/">Hotel Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/landing-page-template/">Landing Page Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/news-template/">News Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/profile-template/">Profile Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/education-template/">Education Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/coming-soon-template/">Coming Soon Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/error-page-template/">Error Page Template<br></a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/event-template/">Event Template<br></a></div>
                </li><li class="nav-item dropdown"><a class="nav-link link dropdown-toggle text-white display-4" href="#" aria-expanded="false" data-toggle="dropdown-submenu">SITE TEMPLATES 2</a><div class="dropdown-menu"><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/about-us-page-template/" aria-expanded="false">About Us Page Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/agency-template/" aria-expanded="false">Agency Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/application-template/" aria-expanded="false">Application Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/business-template/" aria-expanded="false">Business Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/corporate-template/" aria-expanded="false">Corporate Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/homepage-template/" aria-expanded="false">Homepage Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/magazine-template/" aria-expanded="false">Magazine Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/agency-template/multi-page-template.html" aria-expanded="false">Multi Page Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/personal-website-template/" aria-expanded="false">Personal Website Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/photography-template/" aria-expanded="false">Photography Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/store-template/" aria-expanded="false">Store Template</a><a class="dropdown-item text-white display-4" href="https://mobirise.com/bootstrap-4-theme/web-application-template/" aria-expanded="false">Web Application Template</a></div></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-primary display-4" href="https://mobirise.com/mobirise-free-templates.zip">
                    
                    DOWNLOAD NOW</a></div>
        </div>
    </nav>
</section>

<section class="engine"><a href="https://mobirise.co/n">bootstrap modal popup</a></section><section class="cid-qwrivdGaVN mbr-parallax-background" id="header2-0" data-rv-view="6681">

    

    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(35, 35, 35);"></div>

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">&nbsp;Real Estate Template</h1>
                
                <p class="mbr-text pb-3 mbr-fonts-style display-2">
                    Find Your Perfect Home
                </p>
                <div class="mbr-section-btn"><a class="btn btn-md btn-white display-4" href="https://mobirise.com/mobirise-free-templates.zip">DOWNLOAD FREE TEMPLATE</a>
                    <a class="btn btn-md btn-white display-4" href="#">RENT</a></div>
            </div>
        </div>
    </div>
    
</section>

<section class="mbr-section info2 cid-qwwk3lsbaV" id="info2-7" data-rv-view="6684">

    

    

    <div class="container">
        <div class="row justify-content-center">
            <div class="media-container-column col-12 col-lg-3 col-md-4">
                <div class="mbr-section-btn align-left py-4"><a class="btn btn-white display-4" href="index.html#form1-m">
                    
                    CONTACT US</a></div>
            </div>
            <div class="media-container-column title col-12 col-lg-7 col-md-6">
                <h2 class="align-right mbr-bold mbr-white pb-3 mbr-fonts-style display-5">
                    Are you a landlord?</h2>
                <h3 class="mbr-section-subtitle align-right mbr-light mbr-white mbr-fonts-style display-7">
                    Contact us to post your <?php echo e(url('detail')); ?>ing.</h3>
            </div>
        </div>
    </div>
</section>

<section class="features18 popup-btn-cards cid-qwwjt9VJ7s" id="features18-6" data-rv-view="6687">

    

    
    <div class="container">
        <h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-5">Homes For Rent</h2>
        
        <div class="media-container-row pt-5 ">
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper ">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                RENT</a></div>
                        <img src="assets/images/norbert-levajsics-202945-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $3500+
                        </h4>
                        <p class="mbr-text mbr-fonts-style align-left display-7">
                            Renting apartments with a realtor is a rather complicated segment of the real estate market.
                        </p>
                    </div>
                </div>
            </div>
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                RENT</a></div>
                        <img src="assets/images/ian-dooley-331064-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $4310+
                        </h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                           A lot of questions are connected with it. You need to consider the area of the apartment, its condition and location.
                        </p>
                    </div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                RENT</a></div>
                        <img src="assets/images/hannah-busing-310234-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">$4910+</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                           The main problem is the criteria by which the apartment is selected.
                        </p>
                    </div>
                </div>
            </div>

            
        </div>
    </div>
</section>

<section class="features18 popup-btn-cards cid-qwwA6cUyAc" id="features18-c" data-rv-view="6690">

    

    
    <div class="container">
        <h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-5">Studio Apartments</h2>
        
        <div class="media-container-row pt-5 ">
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper ">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">Check availability</a></div>
                        <img src="assets/images/norbert-levajsics-202945-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">$3310+</h4>
                        <p class="mbr-text mbr-fonts-style align-left display-7">A realtor-professional will help you rent or rent an apartment in a short time.</p>
                    </div>
                </div>
            </div>
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">Check availability</a></div>
                        <img src="assets/images/ian-dooley-331064-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $2960+</h4>
                        <p class="mbr-text mbr-fonts-style display-7">At the same time your expenses will be minimal.</p>
                    </div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                Check availability</a></div>
                        <img src="assets/images/hannah-busing-310234-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $3155+
                        </h4>
                        <p class="mbr-text mbr-fonts-style display-7">Most want to rent an apartment for a short time and get a maximum payment for it.
                        </p>
                    </div>
                </div>
            </div>

            
        </div>
    </div>
</section>

<section class="mbr-section content8 cid-qwwvKT2gQm" id="content8-8" data-rv-view="6693">

    

    <div class="container">
        <div class="media-container-row title">
            <div class="col-12 col-md-8">
                <div class="mbr-section-btn align-center"><a class="btn btn-black display-4" href="#">VIEW MORE OFFERS</a></div>
            </div>
        </div>
    </div>
</section>

<section class="header4 cid-qwrivG5j9Z" id="header4-1" data-rv-view="6694">

    

    

    <div class="container">
        <div class="row justify-content-md-center">
            <div class="media-content col-md-10">
                <h2 class="mbr-section-title align-center mbr-white pb-3 mbr-bold mbr-fonts-style display-1">Special Offers</h2>
                
                <div class="mbr-text align-center mbr-white pb-3">
                    <p class="mbr-text mbr-fonts-style display-7">
                        If you want to rent out your apartment, then contacting us for this service will be a good choice.
                    </p>
                </div>
                <div class="mbr-section-btn align-center"><a class="btn btn-md btn-black display-4" href="#">LEARN MORE</a></div>
            </div>
        
            <div class="mbr-figure pt-5" style="width: 60%;">
                <img src="assets/images/colin-maynard-138246-2500x1667.jpg" alt="Mobirise" title="" media-simple="true">
            </div>
        </div>
    </div>
</section>

<section class="cid-qwrixBaSkE" id="image4-2" data-rv-view="6697">
    <!-- Block parameters controls (Blue "Gear" panel) -->
    
    <!-- End block parameters -->
    <div class="container images-container">
            <div class="media-container-row" style="width: 84%;">
                <div class="img-item item1" style="width: 177%;">
                    <img src="assets/images/breather-196135-4928x3280.jpg" alt="" title="" media-simple="true">
                    
                </div>
                <div class="img-item">
                    <img src="assets/images/liana-mikah-343238-6720x4480.jpg" alt="" title="" media-simple="true">
                    
                </div>
            </div>
    </div>
</section>

<section class="features18 popup-btn-cards cid-qwwy5BGprB" id="features18-a" data-rv-view="6699">

    

    
    <div class="container">
        <h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-5">New Homes &amp; Communities</h2>
        
        <div class="media-container-row pt-5 ">
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper ">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                BUY</a></div>
                        <img src="assets/images/norbert-levajsics-202945-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $3310+
                        </h4>
                        <p class="mbr-text mbr-fonts-style align-left display-7">
                            Many residents of the city are faced with the need to rent an apartment or room.
                        </p>
                    </div>
                </div>
            </div>
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                BUY</a></div>
                        <img src="assets/images/ian-dooley-331064-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $3112+
                        </h4>
                        <p class="mbr-text mbr-fonts-style display-7">Country houses and cottages rent for a long time, and for the summer months, and even for a day.</p>
                    </div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                BUY</a></div>
                        <img src="assets/images/hannah-busing-310234-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $2901+
                        </h4>
                        <p class="mbr-text mbr-fonts-style display-7">Before selling an apartment, you should remove obvious drawbacks: clean the room, do cosmetic repairs.
                        </p>
                    </div>
                </div>
            </div>

            
        </div>
    </div>
</section>

<section class="features18 popup-btn-cards cid-qwwyirwUK0" id="features18-b" data-rv-view="6702">

    

    
    <div class="container">
        <h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-5">Newest Listings</h2>
        
        <div class="media-container-row pt-5 ">
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper ">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                BUY</a></div>
                        <img src="assets/images/norbert-levajsics-202945-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $3112+
                        </h4>
                        <p class="mbr-text mbr-fonts-style align-left display-7">
                           Sellers should critically evaluate their apartment, compensate for shortcomings with advantages.
                        </p>
                    </div>
                </div>
            </div>
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                BUY</a></div>
                        <img src="assets/images/ian-dooley-331064-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $2912+
                        </h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                           It is also recommended to pay attention to the merits and for every disadvantage to look for a plus.
                        </p>
                    </div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center"><a href="<?php echo e(url('detail')); ?>" class="btn btn-white display-4">
                                BUY</a></div>
                        <img src="assets/images/hannah-busing-310234-2000x1333.jpg" alt="Mobirise" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            $2812+
                        </h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                           The presence of problematic neighbors often frightens off buyers, and the discount here does not help.
                        </p>
                    </div>
                </div>
            </div>

            
        </div>
    </div>
</section>

<section class="features11 cid-qwriAQHgM0" id="features11-4" data-rv-view="6705">

    

    

    <div class="container">   
        <div class="col-md-12">
            <div class="media-container-row">
                <div class="mbr-figure" style="width: 50%;">
                    <img src="assets/images/joel-filipe-166058-2000x2831.jpg" alt="Mobirise" title="" media-simple="true">
                </div>
                <div class=" align-left">
                    <h2 class="mbr-title pt-2 mbr-fonts-style display-5">Special Offer</h2>
                    <div class="mbr-section-text">
                        <p class="mbr-text mb-5 pt-3 mbr-light mbr-fonts-style display-7">Most experts use a special reduction factor when evaluating apartments located on the last and first floors.
                        </p>
                    </div>

                    <div class="block-content">
                        <div class="card p-3 pr-3">
                            <div class="media">
                                     
                                <div class="media-body">
                                    <h4 class="card-title mbr-fonts-style display-7">2 Bedroom</h4>
                                </div>
                            </div>                

                            <div class="card-box">
                                <p class="block-text mbr-fonts-style display-7">According to the conventional wisdom, such a living space is traditionally considered uncomfortable for living. However, there are exceptions.
                                </p>
                            </div>
                        </div>

                        <div class="card p-3 pr-3">
                            <div class="media">
                                     
                                <div class="media-body">
                                    <h4 class="card-title mbr-fonts-style display-7">1 Bedroom</h4>
                                </div>
                            </div>                

                            <div class="card-box">
                                <p class="block-text mbr-fonts-style display-7">What is attractive for apartments on the last floors? The undeniable advantages of such apartments are a luxurious view from the window and extremely low noise level.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div>          
</section>

<section class="mbr-section form1 cid-qwxa4OcHWG" id="form1-m" data-rv-view="6708">

    

    
    <div class="container">
        <div class="row justify-content-center">
            <div class="title col-12 col-lg-8">
                <h2 class="mbr-section-title align-center pb-3 mbr-fonts-style display-5">CONTACT US</h2>
                <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-7">Our manager will contact you shortly.</h3>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="media-container-column col-lg-8" data-form-type="formoid">
                    <div data-form-alert="" hidden="">
                        Thanks for filling out the form!
                    </div>
            
                    <form class="mbr-form" action="https://mobirise.com/" method="post" data-form-title="Mobirise Form"><input type="hidden" data-form-email="true" value="OAbpAQfh3tb+Os6AQuFLCKCIiVk6G3iHVqEdzIEp3SPXMWw+2BipSsSek3HqaWa4m/lO+wJR3/FseDc6i3i1r7iMXmO8eWaFJ4CiFmOQ+VW0YxAuWpSmjrhX63NnoZsz">
                        <div class="row row-sm-offset">
                            <div class="col-md-4 multi-horizontal" data-for="name">
                                <div class="form-group">
                                    <label class="form-control-label mbr-fonts-style display-7" for="name-form1-m">Name</label>
                                    <input type="text" class="form-control" name="name" data-form-field="Name" required="" id="name-form1-m">
                                </div>
                            </div>
                            <div class="col-md-4 multi-horizontal" data-for="email">
                                <div class="form-group">
                                    <label class="form-control-label mbr-fonts-style display-7" for="email-form1-m">Email</label>
                                    <input type="email" class="form-control" name="email" data-form-field="Email" required="" id="email-form1-m">
                                </div>
                            </div>
                            <div class="col-md-4 multi-horizontal" data-for="phone">
                                <div class="form-group">
                                    <label class="form-control-label mbr-fonts-style display-7" for="phone-form1-m">Phone</label>
                                    <input type="tel" class="form-control" name="phone" data-form-field="Phone" id="phone-form1-m">
                                </div>
                            </div>
                        </div>
                        <div class="form-group" data-for="message">
                            <label class="form-control-label mbr-fonts-style display-7" for="message-form1-m">Message</label>
                            <textarea type="text" class="form-control" name="message" rows="7" data-form-field="Message" id="message-form1-m"></textarea>
                        </div>
            
                        <span class="input-group-btn"><button href="#" type="submit" class="btn btn-form btn-black display-4">SEND FORM</button></span>
                    </form>
            </div>
        </div>
    </div>
</section>

<section class="cid-qwwNJ3yqEe" id="footer1-d" data-rv-view="6711">

    

    

    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-3">
                <div class="media-wrap">
                    <a href="https://mobirise.com/">
                        <img src="assets/images/logo2.png" alt="Mobirise" media-simple="true">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Address
                </h5>
                <p class="mbr-text">
                    1234 Street Name
                    <br>City, AA 99999
                </p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Contacts
                </h5>
                <p class="mbr-text">
                    Email: <a href="https://mobirise.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="0e7d7b7e7e617c7a4e63616c677c677d6b206d6163">[email&#160;protected]</a>
                    <br>Phone: +1 (0) 000 0000 001
                    <br>Fax: +1 (0) 000 0000 002
                </p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Links
                </h5>
                <p class="mbr-text">
                    <a class="text-white" href="https://mobirise.com/">Website builder</a>
                    <br><a class="text-white" href="https://mobirise.com/mobirise-free-win.zip">Download for Windows</a>
                    <br><a class="text-white" href="https://mobirise.com/mobirise-free-mac.zip">Download for Mac</a>
                </p>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-sm-6 copyright">
                    <p class="mbr-text mbr-fonts-style display-7">
                       Bootstrap 4 Real Estate Template © Copyright 2019 <a href="https://mobirise.com/bootstrap-4-theme/" class="text-white">Free Bootstrap 4 Theme</a> - All Rights Reserved
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="social-list align-right">
                        <div class="soc-item">
                            <a href="https://twitter.com/mobirise" target="_blank">
                                <span class="socicon-twitter socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.facebook.com/pages/Mobirise/1616226671953247" target="_blank">
                                <span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.youtube.com/c/mobirise" target="_blank">
                                <span class="socicon-youtube socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://instagram.com/mobirise" target="_blank">
                                <span class="socicon-instagram socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://plus.google.com/u/0/+Mobirise" target="_blank">
                                <span class="socicon-googleplus socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.behance.net/Mobirise" target="_blank">
                                <span class="socicon-behance socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


  <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
</body>

<!-- Mirrored from mobirise.com/bootstrap-4-theme/real-estate-template/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Aug 2019 06:37:26 GMT -->
</html><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/client/index.blade.php ENDPATH**/ ?>