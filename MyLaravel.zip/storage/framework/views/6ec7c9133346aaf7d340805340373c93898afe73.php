<?php $__env->startSection('noidung'); ?>
<h2>PHP</h2>
<?php $__env->stopSection(); ?>
<?php for($i=1; $i<=10;$i++ ): ?>
 	<?php echo e($i . ""); ?>

<?php endfor; ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/pages/php.blade.php ENDPATH**/ ?>