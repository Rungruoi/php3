<form action="<?php echo e(route('postFile')); ?>" method="post" accept-charset="utf-8" enctype="mutipart/form-data">
	
	<input type="file" name="myFile">
	<input type="submit" value="Submit">
	
</form><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/postFile.blade.php ENDPATH**/ ?>