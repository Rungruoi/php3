<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<title>Laravel </title>
</head>
<body >

	<h1>Extends </h1>
	<?php echo $__env->yieldContent('noidung'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/layouts/master.blade.php ENDPATH**/ ?>