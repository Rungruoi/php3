<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('user.editprofile',['id' => Auth::user()->id])); ?>" method="post" enctype="multipart/form-data" novalidate>
	<?php echo csrf_field(); ?>
	<div class="col-md-6">
	<div class="form-group">
	
		<label for="">Tên -(Name)</label>
		<input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>" placeholder="">
		<?php if( $errors->first('name')): ?>
		<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		<?php endif; ?>
	</div>	
	<div class="form-group">
		<input type="hidden" name="id" >

		<label for="">Mật khẩu cũ -(Pass old)</label>
	
		
		<input type="password" name="password" class="form-control"  placeholder="">
		<?php if( $errors->first('password')): ?>
		<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
		<?php endif; ?>
		<?php if(isset($mess)): ?><span class="text-danger"><?php echo e($mess); ?></span>
		<?php endif; ?>
	</div>
	<div class="form-group">
		<input type="hidden" name="id" >
		<label for="">Mật khẩu mới -(Name Pass)</label>
		<input type="password" name="newpass" class="form-control" placeholder="">
		<?php if( $errors->first('newpass')): ?>
		<span class="text-danger"><?php echo e($errors->first('newpass')); ?></span>
		<?php endif; ?>
	</div>
	<div class="form-group">
		<input type="hidden" name="id">
		<label for="">Xác nhận mật khẩu -(Repass)</label>
		<input type="password" name="repass_confirmation" class="form-control" placeholder="">
		<?php if( $errors->first('repass_confirmation')): ?>
		<span class="text-danger"><?php echo e($errors->first('repass_confirmation')); ?></span>
		<?php endif; ?>
	</div>
	</div>
	<div class="col-md-6">
	<div class="form-group">
		<label for="">Địa chỉ-(Address)</label>
		<textarea name="address" id="editor1" rows="10" class="form-control"><?php echo e(Auth::user()->address); ?></textarea>
		<?php if( $errors->first('address')): ?>
		<span class="text-danger"><?php echo e($errors->first('address')); ?></span>
		<?php endif; ?>
	</div>	
	
	<div class="form-group">
		<label for="">Số điện thoại -(Number-phone)</label>
		<input type="number" name="numberphone" class="form-control" value="<?php echo e("0".Auth::user()->numberphone); ?>">
		<?php if( $errors->first('numberphone')): ?>
		<span class="text-danger"><?php echo e($errors->first('numberphone')); ?></span>
		<?php endif; ?>
	</div>
	
	
<div>		<div>
	<button type="submit" class="btn btn-sm btn-success">Lưu</button>
	<a href="<?php echo e(route('homepage')); ?>" class="btn btn-sm btn-danger">Hủy</a>
</div>		</div>
</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\resources\views/user/edit-profile.blade.php ENDPATH**/ ?>